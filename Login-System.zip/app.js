const express = require('express');
const app = express();
const mysql = require('mysql');
const cookieParser = require('cookie-parser'); // Corrected: use proper casing
app.use(cookieParser()); // Ensure cookie-parser middleware is applied once
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/', require('./routes/pages')); // Ensure this file exists and has routes
app.use('/auth', require('./routes/auth')); // Same for auth routes

// Load environment variables from .env
require('dotenv').config({ path: './.env' });

// Set up static folder
const path = require('path');
const location = path.join(__dirname, "./public");
app.use(express.static(location));

// Set up view engine and partials
const hbs = require('hbs');
app.set('view engine', 'hbs');
const partialPath = path.join(__dirname, "./views/partials");
hbs.registerPartials(partialPath);

// MySQL database connection
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASS,
    database: process.env.DATABASE
});

db.connect((err) => {
    if (err) {
        console.log("Database connection failed:", err);
        // You might want to exit or handle the failure more gracefully.
    } else {
        console.log('Database connected successfully');
    }
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
