const mysql = require('mysql');
require('dotenv').config({ path: './.env' }); // Load environment variables from the .env file
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const { promisify } = require('util'); 
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASS,
    database: process.env.DATABASE
});

module.exports.register = (req, res) => {
    const { name, email, password, confirm_password } = req.body;

    // Check if the email already exists in the database
    db.query('SELECT EMAIL FROM users WHERE EMAIL = ?', [email], async (err, results) => {
        if (err) {
            console.log(err);
            return res.status(500).send('Database error');  // Handle database errors gracefully
        }

        // If email already exists, return a message
        if (results.length > 0) {
            return res.render('register', { msg: 'Email already exists' });
        }

        // Check if passwords match
        if (password !== confirm_password) {
            return res.render('register', { msg: 'Passwords do not match' });
        }

        // Hash the password
        let hashedPassword = await bcrypt.hash(password, 8);

        // Insert new user into the database
        const query = 'INSERT INTO users (name, email, pass) VALUES (?, ?, ?)';
        db.query(query, [name, email, hashedPassword], (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send('Database error');
            }

            console.log(result);
            return res.render('register', { msg: 'User registered successfully' });
        });
    });
};


module.exports.login = async(req,res)=>{
   try{
    const {email,password} = req.body;
    if(!email || !password){
        return res.status(400).render('login',{msg : 'please fill out all the fields'})
    }
    
    db.query('select * from users where email = ? ',[email],async (err,response)=>{
        if(response.length <= 0){
            return res.status(401).render('login',{
                msg : "please enter your email and password",
                msg_type : "error"
              })
        }
         if(!response || !(await bcrypt.compare(password,response[0].PASS))){
              return res.status(401).render('login',{
                msg : "please enter your email and password",
                msg_type : "error"
              })
         }   else{
            const id = response[0].ID;
            const token = jwt.sign({id : id},process.env.JWT_SECRET,{
                 expiresIn :  process.env.JWT_EXPIRES_IN
            })
        
            const cookieOption = {
                expires : new Date(
                    Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 *1000            ),
                    httpOnly : true
            }
             res.cookie("hari",token,cookieOption).redirect('/home')
         }
       }
    )
   }catch(error){
    console.log(error)
   }

    
   
}

// Route to serve the home page

  // Middleware to check if the user is logged in
  // Corrected import

exports.isLoggedIn = async (req, res, next) => {
    if (req.cookies.hari) {
        try {
            const decode = await promisify(jwt.verify)(
                req.cookies.hari,
                process.env.JWT_SECRET
            );
            db.query('select * from users where id = ?',[decode.id],(err,results)=>{
                if(!results){
                    return next()
                }
                req.user = results[0];
                return next()
            })
        
        } catch (err) {
            console.log(err);
            return res.status(401).send('Invalid token');
        }
    } else {
        next();
    }
};

  