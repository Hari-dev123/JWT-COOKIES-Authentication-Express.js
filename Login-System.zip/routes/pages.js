const express =require('express');
const { isLoggedIn } = require('../controllers/users');
const route = express.Router()

route.get(['/','/login'],(req,res)=>{
    res.render('login')
})
route.get('/register',(req,res)=>{   
 res.render('register')
})
route.get('/profile',isLoggedIn,(req,res)=>{
  if(req.user){
    res.render('profile',{user : req.user}); 
   }else{
      res.redirect('/')
   }
})
route.get('/home', isLoggedIn, (req, res) => {
     if(req.user){
      res.render('home',{user : req.user}); 
     }else{
        res.redirect('/')
     }

    // Render the home view if the user is logged in
  });
  route.get('/logout', (req, res) => {
    res.clearCookie('hari');
    return res.redirect('/');
});

module.exports = route;